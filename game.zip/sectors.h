#include "sector.h"
vector<item> emptyGround;
sector Andris = sector("Andris", emptyGround, 1);