#include "item.h"
using namespace std;
item dullSword = item("Dull sword", "Weapon", 1);
item chippedHelmet = item("Chipped helmet", "Helmet", 1);
item revivalStone = item("Revival stone", "Artifact", 1);