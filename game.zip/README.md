# adventureGame
Made a console based adventure game. Still very basic, started on 1/29/25
Please contribute if you'd like! Any help is appreciated. Need help thinking of a good storyline :P

## How to play:
#### Download the ZIP file from github & extract it's contents
#### Open terminal and use cd to navigate to the directory. For example, if extracted in Downloads:
####     Mac & Linux: ``cd ~/Downloads/Zandris``
####     Windows: ``cd C:\Users\[your username]\Downloads\Zandris``
#### Compile the game with ``make`` in the directory after downloading and extracting the ZIP file.
#### Run ``./game`` to start the game (runs in terminal)
#### Follow the instructions in the game, and have fun!

### Known bugs: None (just fixed issue where pick didn't erase from ground, stupid mistake lmao)
