# adventureGame
Made a console based adventure game. Still very basic, started on 1/29/25
Please contribute if you'd like! Any help is appreciated. Need help thinking of a good storyline :P

## Computer fixed! Starting work on this repo again starting Feb 19th 2025

### Currently working on: Ability to change sectors
### Currently working on: Making a "shop"
